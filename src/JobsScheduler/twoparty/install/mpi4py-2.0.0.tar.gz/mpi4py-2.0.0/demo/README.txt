Issuing at the command line::

   $ mpiexec -n 5 python helloworld.py

will launch a five-process run of the Python interpreter and execute
the test script ``helloworld.py``, a parallelized version of the
*Hello World!* program.
